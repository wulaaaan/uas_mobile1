package com.example.flashlearn;

import android.content.Intent; // Jangan lupa import ini
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGetStarted = findViewById(R.id.btnGetStarted);

        btnGetStarted.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // PINDAH KE HOME ACTIVITY
                Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                startActivity(intent);

                // Opsional: finish() biar pas di-back ga balik ke sini lagi
                // finish();
            }
        });
    }
}