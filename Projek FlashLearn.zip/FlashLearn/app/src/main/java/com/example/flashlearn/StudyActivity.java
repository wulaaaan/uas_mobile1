package com.example.flashlearn;

import android.app.AlertDialog;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.util.ArrayList;
import java.util.List;

public class StudyActivity extends AppCompatActivity {

    DBHelper myDB;
    TextView tvSubjectTitle, tvCardText;
    ImageButton btnDeleteCard, btnEditCard;
    CardView cardContainer;

    List<FlashcardModel> cardList;

    int currentIndex = 0;
    boolean isFlipped = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study);

        if (getSupportActionBar() != null) getSupportActionBar().hide();

        myDB = new DBHelper(this);

        String subjectName = getIntent().getStringExtra("SUBJECT_NAME");

        tvSubjectTitle = findViewById(R.id.tvSubjectTitle);
        tvCardText = findViewById(R.id.tvCardText);
        cardContainer = findViewById(R.id.cardContainer);

        ImageButton btnBack = findViewById(R.id.btnBackStudy);
        Button btnPrev = findViewById(R.id.btnPrev);
        Button btnNext = findViewById(R.id.btnNext);
        Button btnFlip = findViewById(R.id.btnFlip);
        btnDeleteCard = findViewById(R.id.btnDeleteCard);
        btnEditCard = findViewById(R.id.btnEditCard);

        tvSubjectTitle.setText(subjectName);

        cardList = getCardsFromDB(subjectName);

        if (cardList.isEmpty()) {
            tvCardText.setText("No cards found!");
            btnDeleteCard.setVisibility(View.GONE);
            btnEditCard.setVisibility(View.GONE);
        } else {
            showCard();
        }

        btnBack.setOnClickListener(v -> finish());

        btnFlip.setOnClickListener(v -> {
            if (cardList.isEmpty()) return;
            isFlipped = !isFlipped;
            showCard();
        });

        btnNext.setOnClickListener(v -> {
            if (currentIndex < cardList.size() - 1) {
                currentIndex++;
                isFlipped = false;
                showCard();
            } else {
                Toast.makeText(this, "Last card", Toast.LENGTH_SHORT).show();
            }
        });

        btnPrev.setOnClickListener(v -> {
            if (currentIndex > 0) {
                currentIndex--;
                isFlipped = false;
                showCard();
            }
        });

        btnDeleteCard.setOnClickListener(v -> {
            if (cardList.isEmpty()) return;
            showDeleteConfirmationDialog();
        });

        btnEditCard.setOnClickListener(v -> {
            if (cardList.isEmpty()) return;
            showEditDialog();
        });

        tvCardText.setOnLongClickListener(v -> {
            if (!cardList.isEmpty()) {
                showEditDialog();
                return true;
            }
            return false;
        });
    }

    private void showDeleteConfirmationDialog() {
        FlashcardModel card = cardList.get(currentIndex);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Card");
        builder.setMessage("Delete this card?\n\nQ: " + card.getQuestion());

        builder.setPositiveButton("Delete", (d, w) -> deleteCurrentCard());
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showEditDialog() {
        FlashcardModel card = cardList.get(currentIndex);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Card");

        View view = LayoutInflater.from(this)
                .inflate(R.layout.dialog_edit_card, null);

        EditText etQuestion = view.findViewById(R.id.editTextQuestion);
        EditText etAnswer = view.findViewById(R.id.editTextAnswer);

        etQuestion.setText(card.getQuestion());
        etAnswer.setText(card.getAnswer());

        builder.setView(view);

        builder.setPositiveButton("Save", (d, w) -> {
            String q = etQuestion.getText().toString().trim();
            String a = etAnswer.getText().toString().trim();

            if (q.isEmpty() || a.isEmpty()) {
                Toast.makeText(this, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean updated = myDB.updateFlashcard(
                    card.getId(),
                    card.getSubject(),
                    q,
                    a
            );

            if (updated) {
                card.setQuestion(q);
                card.setAnswer(a);
                Toast.makeText(this, "Updated ✓", Toast.LENGTH_SHORT).show();
                showCard();
            } else {
                Toast.makeText(this, "Update failed", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void deleteCurrentCard() {
        FlashcardModel card = cardList.get(currentIndex);

        if (myDB.deleteFlashcard(card.getId())) {
            cardList.remove(currentIndex);
            Toast.makeText(this, "Card deleted", Toast.LENGTH_SHORT).show();

            if (cardList.isEmpty()) {
                tvCardText.setText("No cards left!");
                tvCardText.setTextColor(Color.parseColor("#424242"));
                btnDeleteCard.setVisibility(View.GONE);
                btnEditCard.setVisibility(View.GONE);
                currentIndex = 0;
            } else {
                if (currentIndex >= cardList.size()) {
                    currentIndex = cardList.size() - 1;
                }
                showCard();
            }
        }
    }

    private void showCard() {
        FlashcardModel card = cardList.get(currentIndex);

        String text;
        int textColor;
        int bgColor;

        if (isFlipped) {
            // Answer mode - Biru tua
            text = "Answer:\n\n" + card.getAnswer();
            textColor = Color.parseColor("#424242"); // Abu-abu gelap
            bgColor = Color.parseColor("#F5F5F5");// Biru muda (background)
        } else {
            // Question mode - Abu-abu gelap
            text = "Question:\n\n" + card.getQuestion();
            textColor = Color.parseColor("#424242"); // Biru tua
            bgColor = Color.parseColor("#CECECE");
             // Abu-abu muda (background)
        }

        // Set teks dan warna
        tvCardText.setText(text + "\n\nCard " +
                (currentIndex + 1) + "/" + cardList.size());
        tvCardText.setTextColor(textColor);

        // Set background card
        cardContainer.setCardBackgroundColor(bgColor);

        btnDeleteCard.setVisibility(View.VISIBLE);
        btnEditCard.setVisibility(View.VISIBLE);
    }

    private List<FlashcardModel> getCardsFromDB(String subject) {
        List<FlashcardModel> list = new ArrayList<>();
        SQLiteDatabase db = myDB.getReadableDatabase();

        Cursor c = db.rawQuery(
                "SELECT id, subject, question, answer, last_reviewed, review_count " +
                        "FROM flashcards WHERE subject = ?",
                new String[]{subject}
        );

        if (c.moveToFirst()) {
            do {
                list.add(new FlashcardModel(
                        c.getInt(0),
                        c.getString(1),
                        c.getString(2),
                        c.getString(3),
                        c.getLong(4),
                        c.getInt(5)
                ));
            } while (c.moveToNext());
        }

        c.close();
        db.close();
        return list;
    }

    @Override
    protected void onResume() {
        super.onResume();
        String subject = getIntent().getStringExtra("SUBJECT_NAME");
        cardList = getCardsFromDB(subject);

        if (cardList.isEmpty()) {
            tvCardText.setText("No cards found!");
            tvCardText.setTextColor(Color.parseColor("#424242"));
            btnDeleteCard.setVisibility(View.GONE);
            btnEditCard.setVisibility(View.GONE);
        } else {
            if (currentIndex >= cardList.size()) {
                currentIndex = cardList.size() - 1;
            }
            showCard();
        }
    }
}