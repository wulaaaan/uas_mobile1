package com.example.flashlearn;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "FlashLearn.db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_FLASHCARDS = "flashcards";
    private static final String COL_ID = "id";
    private static final String COL_SUBJECT = "subject";
    private static final String COL_QUESTION = "question";
    private static final String COL_ANSWER = "answer";
    private static final String COL_LAST_REVIEWED = "last_reviewed";
    private static final String COL_REVIEW_COUNT = "review_count";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // ==================== CREATE TABLE ====================
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_FLASHCARDS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_SUBJECT + " TEXT NOT NULL, " +
                COL_QUESTION + " TEXT NOT NULL, " +
                COL_ANSWER + " TEXT NOT NULL, " +
                COL_LAST_REVIEWED + " INTEGER DEFAULT 0, " +
                COL_REVIEW_COUNT + " INTEGER DEFAULT 0)";
        db.execSQL(createTable);

        db.execSQL("CREATE INDEX idx_subject ON " + TABLE_FLASHCARDS + "(" + COL_SUBJECT + ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FLASHCARDS);
        onCreate(db);
    }

    // ==================== CREATE ====================
    public boolean insertFlashcard(String subject, String question, String answer) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SUBJECT, subject);
        cv.put(COL_QUESTION, question);
        cv.put(COL_ANSWER, answer);

        long result = db.insert(TABLE_FLASHCARDS, null, cv);
        db.close();
        return result != -1;
    }

    // ==================== READ ====================
    public List<String> getAllSubjects() {
        List<String> subjects = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT DISTINCT " + COL_SUBJECT + " FROM " + TABLE_FLASHCARDS + " ORDER BY " + COL_SUBJECT,
                null
        );

        if (cursor.moveToFirst()) {
            do {
                subjects.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return subjects;
    }

    public List<FlashcardModel> getFlashcardsBySubject(String subject) {
        List<FlashcardModel> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_FLASHCARDS,
                null,
                COL_SUBJECT + " = ?",
                new String[]{subject},
                null, null,
                COL_ID + " ASC"
        );

        if (cursor.moveToFirst()) {
            do {
                list.add(parseFlashcard(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    public FlashcardModel getFlashcardById(int id) {
        SQLiteDatabase db = getReadableDatabase();
        FlashcardModel card = null;

        Cursor cursor = db.query(
                TABLE_FLASHCARDS,
                null,
                COL_ID + " = ?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        if (cursor.moveToFirst()) {
            card = parseFlashcard(cursor);
        }

        cursor.close();
        db.close();
        return card;
    }

    public List<FlashcardModel> getAllFlashcards() {
        List<FlashcardModel> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_FLASHCARDS,
                null,
                null, null, null, null,
                COL_SUBJECT + " ASC, " + COL_ID + " ASC"
        );

        if (cursor.moveToFirst()) {
            do {
                list.add(parseFlashcard(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return list;
    }

    // ==================== UPDATE ====================
    public boolean updateFlashcard(int id, String subject, String question, String answer) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_SUBJECT, subject);
        cv.put(COL_QUESTION, question);
        cv.put(COL_ANSWER, answer);

        int result = db.update(
                TABLE_FLASHCARDS,
                cv,
                COL_ID + " = ?",
                new String[]{String.valueOf(id)}
        );
        db.close();
        return result > 0;
    }

    public void markReviewed(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(
                "UPDATE " + TABLE_FLASHCARDS +
                        " SET " + COL_REVIEW_COUNT + " = " + COL_REVIEW_COUNT + " + 1, " +
                        COL_LAST_REVIEWED + " = ? WHERE " + COL_ID + " = ?",
                new Object[]{System.currentTimeMillis(), id}
        );
        db.close();
    }

    // ==================== DELETE ====================
    public boolean deleteFlashcard(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int result = db.delete(TABLE_FLASHCARDS, COL_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    public boolean deleteSubject(String subject) {
        SQLiteDatabase db = getWritableDatabase();
        int result = db.delete(TABLE_FLASHCARDS, COL_SUBJECT + " = ?", new String[]{subject});
        db.close();
        return result > 0;
    }

    public void deleteAllFlashcards() {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_FLASHCARDS, null, null);
        db.close();
    }

    // ==================== STATS ====================
    public int getTotalFlashcardCount() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM " + TABLE_FLASHCARDS, null);

        int count = 0;
        if (cursor.moveToFirst()) count = cursor.getInt(0);

        cursor.close();
        db.close();
        return count;
    }

    // ==================== HELPER ====================
    private FlashcardModel parseFlashcard(Cursor c) {
        return new FlashcardModel(
                c.getInt(c.getColumnIndexOrThrow(COL_ID)),
                c.getString(c.getColumnIndexOrThrow(COL_SUBJECT)),
                c.getString(c.getColumnIndexOrThrow(COL_QUESTION)),
                c.getString(c.getColumnIndexOrThrow(COL_ANSWER)),
                c.getLong(c.getColumnIndexOrThrow(COL_LAST_REVIEWED)),
                c.getInt(c.getColumnIndexOrThrow(COL_REVIEW_COUNT))
        );
    }
}
