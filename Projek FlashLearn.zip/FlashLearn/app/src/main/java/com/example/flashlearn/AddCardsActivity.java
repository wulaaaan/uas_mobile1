package com.example.flashlearn;

import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AddCardsActivity extends AppCompatActivity {

    private static final int MAX_LENGTH = 180;

    private AutoCompleteTextView etSubject;
    private EditText etQuestion, etAnswer;
    private TextView tvCounterQuestion, tvCounterAnswer;
    private Button btnSave;
    private ImageButton btnBackAdd;

    private DBHelper myDB;
    private List<String> existingSubjects;
    private ArrayAdapter<String> subjectAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_cards);

        myDB = new DBHelper(this);

        // Init views
        btnBackAdd = findViewById(R.id.btnBackAdd);
        etSubject = findViewById(R.id.etSubject);
        etQuestion = findViewById(R.id.etQuestion);
        etAnswer = findViewById(R.id.etAnswer);
        btnSave = findViewById(R.id.btnSave);
        tvCounterQuestion = findViewById(R.id.tvCounterQuestion);
        tvCounterAnswer = findViewById(R.id.tvCounterAnswer);

        // Limit 180 karakter (huruf + spasi)
        etQuestion.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_LENGTH)
        });
        etAnswer.setFilters(new InputFilter[]{
                new InputFilter.LengthFilter(MAX_LENGTH)
        });

        // Setup counter
        setupCounter(etQuestion, tvCounterQuestion);
        setupCounter(etAnswer, tvCounterAnswer);

        // Load subjects
        existingSubjects = myDB.getAllSubjects();

        // ⚠️ Pakai layout custom dropdown item (RECOMMENDED)
        subjectAdapter = new ArrayAdapter<>(
                this,
                R.layout.item_dropdown_subject,
                existingSubjects
        );
        etSubject.setAdapter(subjectAdapter);
        etSubject.setThreshold(1);

        // Show dropdown when clicked
        etSubject.setOnClickListener(v -> etSubject.showDropDown());

        // Ambil subject dari intent (jika ada)
        String subjectFromIntent = getIntent().getStringExtra("SUBJECT_NAME");
        if (subjectFromIntent != null) {
            etSubject.setText(subjectFromIntent);
            etQuestion.requestFocus();
        }

        // Back button
        btnBackAdd.setOnClickListener(v -> finish());

        // Save card
        btnSave.setOnClickListener(v -> saveCard());

        // Auto focus ke question setelah pilih subject
        etSubject.setOnItemClickListener((parent, view, position, id) ->
                etQuestion.requestFocus()
        );
    }

    private void saveCard() {
        String subject = etSubject.getText().toString().trim();
        String question = etQuestion.getText().toString().trim();
        String answer = etAnswer.getText().toString().trim();

        if (subject.isEmpty() || question.isEmpty() || answer.isEmpty()) {
            Toast.makeText(this,
                    "Please fill all fields!",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        boolean inserted = myDB.insertFlashcard(subject, question, answer);

        if (inserted) {
            Toast.makeText(this,
                    "✓ Card added successfully!",
                    Toast.LENGTH_SHORT).show();

            // Tambah subject baru ke dropdown
            if (!existingSubjects.contains(subject)) {
                existingSubjects.add(0, subject);
                subjectAdapter.notifyDataSetChanged();
            }

            // Clear input (subject tetap)
            etQuestion.setText("");
            etAnswer.setText("");
            etQuestion.requestFocus();

        } else {
            Toast.makeText(this,
                    "Failed to add card!",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void setupCounter(EditText editText, TextView counter) {
        counter.setText("0/" + MAX_LENGTH);

        editText.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                counter.setText(s.length() + "/" + MAX_LENGTH);
            }

            @Override public void afterTextChanged(Editable s) {}
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshSubjectSuggestions();
    }

    private void refreshSubjectSuggestions() {
        List<String> updatedSubjects = myDB.getAllSubjects();
        existingSubjects.clear();
        existingSubjects.addAll(updatedSubjects);
        subjectAdapter.notifyDataSetChanged();
    }
}
