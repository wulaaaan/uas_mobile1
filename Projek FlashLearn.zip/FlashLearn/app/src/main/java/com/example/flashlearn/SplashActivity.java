package com.example.flashlearn;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SplashActivity extends AppCompatActivity {

    private TextView tvWelcome;
    private ImageView imgFlag;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;

    // Waktu delay splash screen (3 detik)
    private static final int SPLASH_DELAY = 3000;
    private boolean isNavigating = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        tvWelcome = findViewById(R.id.tvSplash);
        imgFlag = findViewById(R.id.imgFlag);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Set Default: Fast Learning, Easy Thinking (English/US)
        updateUI("US");

        if (checkLocationPermission()) {
            getLocationAndSetUI();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private boolean checkLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("MissingPermission")
    private void getLocationAndSetUI() {
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            determineCountry(location.getLatitude(), location.getLongitude());
                        } else {
                            moveToMainActivity();
                        }
                    }
                });
    }

    private void determineCountry(double lat, double lon) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lon, 1);
            if (addresses != null && !addresses.isEmpty()) {
                String countryCode = addresses.get(0).getCountryCode();
                updateUI(countryCode);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        moveToMainActivity();
    }

    private void updateUI(String countryCode) {
        runOnUiThread(() -> {
            if (countryCode == null) return;

            switch (countryCode.toUpperCase()) {
                case "ID": // Indonesia
                    // "Belajar Cepat, Berpikir Mudah"
                    tvWelcome.setText("Belajar Cepat, Berpikir Mudah");
                    imgFlag.setImageResource(R.drawable.flag_id);
                    break;

                case "JP": // Jepang
                    // "Fast Learning, Easy Thinking" (Hayai Gakushu, Kantan na Shiko)
                    tvWelcome.setText("速い学習、簡単な思考");
                    imgFlag.setImageResource(R.drawable.flag_jp);
                    break;

                case "KR": // Korea
                    // "Fast Learning, Easy Thinking" (Ppareun Hakseup, Swiun Saenggak)
                    tvWelcome.setText("빠른 학습, 쉬운 생각");
                    imgFlag.setImageResource(R.drawable.flag_kr);
                    break;

                case "CN": // China
                    // "Fast Learning, Easy Thinking" (Kuàisù Xuéxí, Qīngsōng Sīkǎo)
                    tvWelcome.setText("快速学习，轻松思考");
                    imgFlag.setImageResource(R.drawable.flag_china);
                    break;

                case "BR": // Brazil
                    // "Fast Learning, Easy Thinking" (Aprendizado Rápido, Pensamento Fácil)
                    tvWelcome.setText("Aprendizado Rápido, Pensamento Fácil");
                    imgFlag.setImageResource(R.drawable.flag_brazil);
                    break;

                case "US": // USA
                default: // Default Global
                    tvWelcome.setText("Fast Learning, Easy Thinking");
                    imgFlag.setImageResource(R.drawable.flag_us);
                    break;
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocationAndSetUI();
            } else {
                Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
                moveToMainActivity();
            }
        }
    }

    private void moveToMainActivity() {
        if (isNavigating) return;
        isNavigating = true;

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(SplashActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }, SPLASH_DELAY);
    }
}