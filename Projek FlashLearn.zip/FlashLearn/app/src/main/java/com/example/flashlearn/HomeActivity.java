package com.example.flashlearn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class HomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // 1. Sembunyikan Action Bar biar bersih
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        // --- TOMBOL 1: FLASHCARDS (BELAJAR) ---
        Button btnFlashcards = findViewById(R.id.btnFlashcards);
        btnFlashcards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke menu FlashcardsActivity
                Intent intent = new Intent(HomeActivity.this, FlashcardsActivity.class);
                startActivity(intent);
            }
        });

        // --- TOMBOL 2: ADD CARDS (TAMBAH KARTU) ---
        Button btnAddCards = findViewById(R.id.btnAddCards);
        btnAddCards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke menu AddCardsActivity
                Intent intent = new Intent(HomeActivity.this, AddCardsActivity.class);
                startActivity(intent);
            }
        });
    }
}