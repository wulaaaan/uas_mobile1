package com.example.flashlearn;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class FlashcardsActivity extends AppCompatActivity {

    private DBHelper myDB;
    private LinearLayout containerSubjects;
    private EditText etSearch;
    private ImageButton btnClearSearch;
    private List<String> allSubjects;
    private List<String> filteredSubjects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flashcards);

        // Sembunyikan ActionBar
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        myDB = new DBHelper(this);

        // Inisialisasi view
        ImageButton btnBack = findViewById(R.id.btnBack);
        containerSubjects = findViewById(R.id.containerSubjects);
        etSearch = findViewById(R.id.etSearch);
        btnClearSearch = findViewById(R.id.btnClearSearch);

        btnBack.setOnClickListener(v -> finish());

        // Setup search functionality
        setupSearchBar();

        loadSubjects();
    }

    private void setupSearchBar() {
        // Listener untuk search bar
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Tampilkan/sembunyikan clear button
                btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                // Filter subjects
                filterSubjects(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Clear button functionality
        btnClearSearch.setOnClickListener(v -> {
            etSearch.setText("");
            filterSubjects("");
        });
    }

    private void filterSubjects(String query) {
        if (filteredSubjects == null) return;

        filteredSubjects.clear();

        if (query.isEmpty()) {
            // Jika search kosong, tampilkan semua
            filteredSubjects.addAll(allSubjects);
        } else {
            // Filter berdasarkan query
            String lowerCaseQuery = query.toLowerCase().trim();
            for (String subject : allSubjects) {
                if (subject.toLowerCase().contains(lowerCaseQuery)) {
                    filteredSubjects.add(subject);
                }
            }
        }

        displaySubjects();
    }

    private void displaySubjects() {
        // Hapus semua view yang ada
        containerSubjects.removeAllViews();

        if (filteredSubjects.isEmpty()) {
            // Tampilkan pesan tidak ditemukan atau kosong
            TextView tvMessage = new TextView(this);

            if (etSearch.getText().toString().trim().isEmpty()) {
                // Jika tidak ada subject sama sekali
                tvMessage.setText("No flashcards yet!\nAdd cards first.");
            } else {
                // Jika search tidak menemukan hasil
                tvMessage.setText("No subjects found for: '" + etSearch.getText() + "'");
            }

            tvMessage.setTextSize(18);
            tvMessage.setTextColor(Color.parseColor("#757575"));
            tvMessage.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            tvMessage.setPadding(0, 100, 0, 0);
            containerSubjects.addView(tvMessage);
            return;
        }

        // Buat tombol untuk setiap subject
        for (String subject : filteredSubjects) {
            MaterialButton btn = new MaterialButton(this);

            // Atur tampilan tombol
            btn.setText(subject);
            btn.setTextSize(18);
            btn.setTextColor(Color.WHITE);
            btn.setBackgroundColor(Color.parseColor("#494547"));
            btn.setCornerRadius(30);
            btn.setAllCaps(false);

            // Atur ukuran dan margin
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    180
            );
            params.setMargins(0, 0, 0, 16);
            btn.setLayoutParams(params);

            // Klik untuk masuk ke StudyActivity
            btn.setOnClickListener(v -> {
                Intent intent = new Intent(FlashcardsActivity.this, StudyActivity.class);
                intent.putExtra("SUBJECT_NAME", subject);
                startActivity(intent);
            });

            // Long press untuk menu edit/hapus
            btn.setOnLongClickListener(v -> {
                showSimpleMenu(subject);
                return true;
            });

            containerSubjects.addView(btn);
        }
    }

    private void loadSubjects() {
        // Ambil semua subject dari database
        allSubjects = myDB.getAllSubjects();
        filteredSubjects = new ArrayList<>(allSubjects);

        // Display subjects
        displaySubjects();
    }

    private void showSimpleMenu(String subject) {
        String[] options = {"Edit", "Delete", "Cancel"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(subject);
        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0: // Edit
                    showEditDialog(subject);
                    break;
                case 1: // Delete
                    showDeleteDialog(subject);
                    break;
            }
        });
        builder.show();
    }

    private void showEditDialog(String oldSubject) {
        // Buat dialog edit sederhana
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_simple_edit, null);
        TextView tvTitle = dialogView.findViewById(R.id.tvTitle);
        TextView etSubject = dialogView.findViewById(R.id.etSubject);

        tvTitle.setText("Edit Subject");
        etSubject.setText(oldSubject);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setPositiveButton("Save", (dialog, which) -> {
            String newSubject = etSubject.getText().toString().trim();
            if (!newSubject.isEmpty() && !newSubject.equals(oldSubject)) {
                // Update semua kartu dengan subject baru
                List<FlashcardModel> cards = myDB.getFlashcardsBySubject(oldSubject);
                for (FlashcardModel card : cards) {
                    myDB.updateFlashcard(card.getId(), newSubject,
                            card.getQuestion(), card.getAnswer());
                }
                Toast.makeText(this, "Subject updated", Toast.LENGTH_SHORT).show();
                loadSubjects(); // Refresh
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showDeleteDialog(String subject) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete " + subject + "?");
        builder.setMessage("All cards in this subject will be deleted.");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            if (myDB.deleteSubject(subject)) {
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
                loadSubjects();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadSubjects(); // Refresh saat kembali
    }
}