package com.example.flashlearn;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class FlashcardModel {

    private int id;
    private String subject;
    private String question;
    private String answer;
    private long lastReviewed;
    private int reviewCount;

    // Constructor kartu baru (tanpa ID)
    public FlashcardModel(String subject, String question, String answer) {
        this(0, subject, question, answer, System.currentTimeMillis(), 0);
    }

    // Constructor lengkap (load dari database)
    public FlashcardModel(int id, String subject, String question, String answer,
                          long lastReviewed, int reviewCount) {
        this.id = id;
        this.subject = subject;
        this.question = question;
        this.answer = answer;
        this.lastReviewed = lastReviewed;
        this.reviewCount = reviewCount;
    }

    // ================= GETTERS =================
    public int getId() { return id; }
    public String getSubject() { return subject; }
    public String getQuestion() { return question; }
    public String getAnswer() { return answer; }
    public long getLastReviewed() { return lastReviewed; }
    public int getReviewCount() { return reviewCount; }

    // ================= SETTERS =================
    public void setId(int id) { this.id = id; }
    public void setSubject(String subject) { this.subject = subject; }
    public void setQuestion(String question) { this.question = question; }
    public void setAnswer(String answer) { this.answer = answer; }
    public void setLastReviewed(long lastReviewed) { this.lastReviewed = lastReviewed; }
    public void setReviewCount(int reviewCount) { this.reviewCount = reviewCount; }

    // ============== HELPER METHODS ==============

    // Format lastReviewed ke teks manusiawi
    public String getLastReviewedFormatted() {
        if (lastReviewed == 0) return "Never reviewed";

        long diff = System.currentTimeMillis() - lastReviewed;
        long minutes = diff / (1000 * 60);
        long hours = minutes / 60;
        long days = hours / 24;

        if (days > 0) return days + " day" + (days > 1 ? "s" : "") + " ago";
        if (hours > 0) return hours + " hour" + (hours > 1 ? "s" : "") + " ago";
        if (minutes > 0) return minutes + " minute" + (minutes > 1 ? "s" : "") + " ago";
        return "Just now";
    }

    // Format tanggal lengkap
    public String getLastReviewedDate() {
        if (lastReviewed == 0) return "Not reviewed yet";
        SimpleDateFormat sdf =
                new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault());
        return sdf.format(new Date(lastReviewed));
    }

    // Progress review (0–100%)
    public int getReviewProgress() {
        if (reviewCount <= 0) return 0;
        if (reviewCount >= 10) return 100;
        return reviewCount * 10;
    }

    // Status review
    public String getReviewStatus() {
        if (reviewCount == 0) return "New card";
        if (reviewCount < 3) return "Learning (" + reviewCount + "/3)";
        if (reviewCount < 5) return "Familiar (" + reviewCount + "/5)";
        if (reviewCount < 10) return "Mastered (" + reviewCount + "/10)";
        return "Fully mastered!";
    }

    // Update review
    public void updateAfterReview() {
        reviewCount++;
        lastReviewed = System.currentTimeMillis();
    }

    // Reset review
    public void resetReview() {
        reviewCount = 0;
        lastReviewed = System.currentTimeMillis();
    }

    // ================= OVERRIDE =================

    @Override
    public String toString() {
        return "FlashcardModel{" +
                "id=" + id +
                ", subject='" + subject + '\'' +
                ", question='" + question + '\'' +
                ", answer='" + answer + '\'' +
                ", lastReviewed=" + getLastReviewedFormatted() +
                ", reviewCount=" + reviewCount +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FlashcardModel)) return false;
        FlashcardModel that = (FlashcardModel) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return id;
    }

    // ================= STATIC =================

    public static FlashcardModel createNew(String subject, String question, String answer) {
        return new FlashcardModel(subject, question, answer);
    }

    public static boolean isValid(FlashcardModel card) {
        return card != null &&
                card.subject != null && !card.subject.trim().isEmpty() &&
                card.question != null && !card.question.trim().isEmpty() &&
                card.answer != null && !card.answer.trim().isEmpty();
    }

    // Clone
    public FlashcardModel clone() {
        return new FlashcardModel(
                this.id,
                this.subject,
                this.question,
                this.answer,
                this.lastReviewed,
                this.reviewCount
        );
    }

    // Export CSV
    public String toCSV() {
        return String.format(Locale.US, "%d,\"%s\",\"%s\",\"%s\",%d,%d",
                id,
                subject.replace("\"", "\"\""),
                question.replace("\"", "\"\""),
                answer.replace("\"", "\"\""),
                lastReviewed,
                reviewCount);
    }

    // Import CSV
    public static FlashcardModel fromCSV(String csvLine) {
        try {
            String[] p = csvLine.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");
            int id = Integer.parseInt(p[0]);
            String subject = p[1].replace("\"", "");
            String question = p[2].replace("\"", "");
            String answer = p[3].replace("\"", "");
            long lastReviewed = Long.parseLong(p[4]);
            int reviewCount = Integer.parseInt(p[5]);

            return new FlashcardModel(id, subject, question, answer, lastReviewed, reviewCount);
        } catch (Exception e) {
            return null;
        }
    }
}
